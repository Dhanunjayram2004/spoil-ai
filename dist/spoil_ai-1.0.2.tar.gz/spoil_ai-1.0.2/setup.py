from setuptools import setup, find_packages

setup(
    name="spoil-ai",
    version="1.0.2",
    description="An autonomous Linux assistant that writes commands, installs missing dependencies, and executes tasks.",
    author="Dhanunjay Ram Yellapu",
    py_modules=["main"],
    packages=find_packages(),
    install_requires=[
        "openai",
    ],
    entry_points={
        "console_scripts": [
            "ai=main:main",
        ],
    },
)
